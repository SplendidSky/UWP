﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LifecycleDemo.Models
{
    class MyDataItem
    {
        public string Field1 { get; set; }
        public string Field2 { get; set; }
    }
}
